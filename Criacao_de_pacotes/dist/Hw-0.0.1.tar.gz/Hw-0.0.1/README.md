# Hw

Description. 
The package package_name is used to:
- print Hello world

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Hw

```bash
pip install Hw
```

## Usage

```python
from Hw import file1_name
file1_name.my_function()
```

## Author
Leticia Gomes

## License
[MIT](https://choosealicense.com/licenses/mit/)